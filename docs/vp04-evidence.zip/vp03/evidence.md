# VP-03 desktop viewport evidence

| Evidence | Value |
| --- | --- |
| Studio base | f084adc8341610205cd0df63af57289a2183036a |
| Desktop shell SHA-256 | 6c86766df8c4e50fb90a611f936830397db7739f108ef13083b6b2b8784bb469 |
| Native source SHA-256 | e2628f89bd6457fc3bd903564413d4ee413499dd7cf37dedd9cc2177b8e51566 |
| CDP endpoint | Per-lane loopback port (recorded in WebView2 flags) |
| Runtime revision | d6459a26f04c637909360a0351c7ed98d6e0b84a |
| Archive SHA-256 | 523493d8e22434def1091d68a7b427e55aac18588861b0932ea99fcf41b83eaa |
| Served Viewport3D.tsx SHA-256 | 866ad5da4c65cdd5518856d0fe4f9848bd198d7be0fe23c798c7f80f285ebb1c |
| First-party executables verified | 58 |
| Viewport runtime files observed | 215 |
| DEM fixture | samples/bryce-terrain.studio3d |
| DEM SHA-256 | 5d6f34b93f2c8a2d18ee077629b2b940e3a0ac610625854abb25f51fe37767db |
| Empty fixture SHA-256 | 30a9b35d42fd90bae755ea10c4e66649d4a1c2485d7f8a140d4b0dd259c73b94 |
| Renderer and mode | Auto, Solid |
| Disabled settings | Sun shadows, Terrain sun shadows, custom HDRI, imagery, cartography, hillshade and grids |
| Desktop | Edg/157.0.4341.60 |
| Native engine | Forge3D 1.52.0 · Vulkan · NVIDIA GeForce RTX 3070 |

Five-state test **passed**

| State | Project generation / revision | Terrain revision SHA-256 prefix | Physical size | Backend | Submission / event | Runtime / context | Successful WebGL | Readback pixels | Display pixels | Compositor color matches | Query |
| --- | --- | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| 01-open-empty | 1 / 0 | — | 794 × 794 | Viewport forge3d-web · WebGPU available | 1 / 6 | 1 / 2 | 0 | 0 | 0 | — | Miss |
| 02-import-dem | 1 / 1 | 2ba367cb452d | 794 × 794 | Viewport forge3d-web · WebGPU available | 3 / 13 | 1 / 2 | 0 | 262293 | 254789 | 253152 / 253152 | Hit, 2275.665 m |
| 03-hide-dem | 1 / 2 | 2ba367cb452d | 794 × 794 | Viewport forge3d-web · WebGPU available | 4 / 21 | 2 / 2 | 0 | 0 | 0 | — | Miss |
| 04-show-dem | 1 / 3 | 2ba367cb452d | 794 × 794 | Viewport forge3d-web · WebGPU available | 6 / 26 | 2 / 2 | 0 | 262293 | 254789 | 253152 / 253152 | Hit, 2275.665 m |
| 05-delete-dem | 1 / 4 | — | 794 × 794 | Viewport forge3d-web · WebGPU available | 8 / 35 | 3 / 2 | 0 | 0 | 0 | — | Miss |

- staleSurfaceControl passed
- fiveStates passed
- matchingTerrainControls passed
- staleUpload passed
- staleCamera passed
- nativeVisibility passed
- retiredQuery passed
- staleGeometry passed
- staleQueryHeights passed
- wideFootprints passed
- late-hide passed
- late-project passed
- limit passed
- committedReplacement passed
- resize passed
- lateCreationReplacement passed
- lateCreationUnmount passed
- remote-invalid-format passed
- remote-rgb-tiff passed
- remote-rgb-cog passed
- remote-intensity-no-georeference passed
- remote-all-nodata passed
- editedGalleryUrl passed
- staleQueryControl passed
- remoteCOG passed
- legacyRemoteNative passed
- uploadDuringRead passed
- nativeRetirement passed
- sceneErrorRecovery passed
- visibleNativeSize passed
- budgetAdmission passed
- rejectedTerrainBudget passed
- interruptedAdmission passed
- remount-admission passed
- remount-creation passed
- remount-diagnostic passed
- remount-control passed
- fractionalDatum passed
- remoteScale passed
- wrongPreviewSource passed
- fractionalDisplay passed
- nativeTerrainPlacement passed
- editorBudgetAdmission passed
- editorSkippedFrame passed
- hybrid passed
- override passed
- fallback passed
- native passed
- editorUnusableLimit passed
- wrongSize passed
- invalidPreviewRetry passed
- executableTamper passed

Unexercised cases Authenticated COG endpoints, Public HTTPS COG, Replay of the frozen VP-01 capture

The JSON records full revision values, served asset hashes, fixtures, settings and instance lifetimes.
