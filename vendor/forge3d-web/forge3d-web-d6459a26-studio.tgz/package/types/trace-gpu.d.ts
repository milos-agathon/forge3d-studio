import { TraceScene } from "./trace-scene.js";
import type { CpuTraceSettings } from "./trace-cpu.js";
export { packTraceScene, traceUniform } from './trace-packets.js';
import { packTraceScene } from './trace-packets.js';
export declare function requestTraceDevice(minStorageBytes?: number): Promise<GPUDevice>;
export declare class TraceGpu {
    #private;
    readonly device: GPUDevice;
    readonly source: TraceScene;
    readonly settings: CpuTraceSettings;
    readonly budget: number;
    readonly ownsDevice: boolean;
    readonly packed: ReturnType<typeof packTraceScene>;
    readonly bytes: number;
    private constructor();
    static create(device: GPUDevice, scene: TraceScene, settings: CpuTraceSettings, budget: number, ownsDevice?: boolean, engine?: "megakernel" | "wavefront"): Promise<TraceGpu>;
    /** Retained GPU allocations, independent of the admission estimate. */
    get allocatedBytes(): number;
    checkAlive(): void;
    exportReservoirs(): Promise<ArrayBuffer>;
    restore(sum: Float32Array, reservoirs: ArrayBuffer): void;
    reset(): void;
    sample(sample: number, engine: "megakernel" | "wavefront", signal?: AbortSignal): Promise<Float32Array>;
    dispose(): void;
}
